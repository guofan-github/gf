# 1 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c"
# 1 "D:\\lr\\include/lrun.h" 1
 
 












 











# 103 "D:\\lr\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "D:\\lr\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "D:\\lr\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "D:\\lr\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "D:\\lr\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "D:\\lr\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "D:\\lr\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "D:\\lr\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "D:\\lr\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "D:\\lr\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "D:\\lr\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "D:\\lr\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "D:\\lr\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "D:\\lr\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "D:\\lr\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "D:\\lr\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "D:\\lr\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "D:\\lr\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "D:\\lr\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "D:\\lr\\include/lrun.h"


# 1075 "D:\\lr\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "D:\\lr\\include/SharedParameter.h" 1



 
 
 
 
# 100 "D:\\lr\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "globals.h" 1



 
 

# 1 "D:\\lr\\include/web_api.h" 1







# 1 "D:\\lr\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "D:\\lr\\include/as_web.h"


# 802 "D:\\lr\\include/as_web.h"



























# 840 "D:\\lr\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "D:\\lr\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "D:\\lr\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 8 "globals.h" 2


 
 


# 3 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "Action1.c" 1
Action1()
{	 
	web_reg_find("Search=Body",
	"SaveCount=dl",
	"Text=郭凡",
	"LAST");

	lr_start_transaction("登录事务");
	
	web_reg_save_param_json(
	"ParamName=token",
	"QueryString=$.data",
	"SEARCH_FILTERS",
	"Scope=BODY",
	"LAST");
	
	web_custom_request("登录",
	"URL=http://{url}/water_bg/user/login",
	"Method=POST",
	"TargetFrame=",
	"Resource=0",
	"RecContentType=application/json;charset=UTF-8",
	"Referer=",
	"EncType=application/json;charset=UTF-8",
	"Body={\"userName\":\"admin\",\"password\":\"123\"}",
	"LAST");
	
	lr_output_message("数量%s",lr_eval_string("{dl}"));
 
	if(atoi(lr_eval_string("{dl}"))==1){
	lr_end_transaction("登录事务",0);
	}else{
    lr_end_transaction("登录事务",1);
	}
	
	 
	lr_start_transaction("基础设施事务");
	
	web_reg_find("Search=Body",
	"SaveCount=bj",
	"Text=OK",
	"LAST");

	
	web_add_header("Authorization",
		"{token}");

	
	web_custom_request("基础设施编辑",
		"URL=http://{url}/water_bg/base/updateBaseType",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"i\":1,\"baseId\":8,\"name\":\"lbw广场\",\"longitude\":110,\"latitude\":120,\"useTime\":\"2021-03-09\",\"address\":\"卢本伟顶顶顶顶\",\"describe\":\"用于武昌区的用水\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{bj}"))==2){
	 lr_output_message("基础设施编辑事务测试成功");
	}else{
     lr_output_message("基础设施编辑事务测试失败");
	}
	
	 
	
	web_reg_find("Search=Body",
	"SaveCount=xq",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("web_url",
		"URL=http://{url}/water_bg/child/getChild?id=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	if(atoi(lr_eval_string("{xq}"))==1){
	 lr_output_message("基础设施详情事务测试成功");
	}else{
     lr_output_message("基础设施详情事务测试失败");
	}
	
	 
	
	web_reg_find("Search=Body",
	"SaveCount=xj",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("基础设施修改",
		"URL=http://{url}/water_bg/child/updateChild",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":13,\"stockChildId\":1,\"childName\":\"王莹大傻\",\"childStatus\":\"良好\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{xj}"))==2){
	 lr_output_message("基础设施修改事务测试成功");
	}else{
     lr_output_message("基础设施修改事务测试失败");
	}
	
	 
	
	web_reg_find("Search=Body",
	"SaveCount=tj",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("基础设施添加",
		"URL=http://{url}/water_bg/child/addChild",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"stockChildId\":1,\"childName\":\"666\",\"childStatus\":\"良好\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{tj}"))==2){
	 lr_output_message("基础设施添加事务测试成功");
	}else{
     lr_output_message("基础设施添加事务测试失败");
	}
	
	 
	
	web_reg_find("Search=Body",
	"SaveCount=sq",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("web_url",
		"URL=http://{url}/water_bg/ask/askStock?id=1&reason=44&askNum=4",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	if(atoi(lr_eval_string("{sq}"))==2){
	lr_end_transaction("基础设施事务",0);
	}else{
    lr_end_transaction("基础设施事务",1);
	}
	
	 
	lr_start_transaction("设备列表事务");
	
	web_reg_find("Search=Body",
	"SaveCount=cx",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("设备列表查询",
		"URL=http://{url}/water_bg/device/getAll?pageIndex=1&pageSize=6",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"no\":\"55\",\"name\":\"\",\"buyUser\":\"\",\"checkUser\":\"\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{cx}"))==1){
	 lr_output_message("设备列表查询事务测试成功");
	}else{
     lr_output_message("设备列表查询事务测试失败");
	}
	
	 
	web_reg_find("Search=Body",
	"SaveCount=sbxq",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("设备列表详情",
		"URL=http://{url}/water_bg/basestock/getBaseStock?id=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{sbxq}"))==1){
	 lr_output_message("设备列表详情测试成功");
	}else{
     lr_output_message("设备列表详情测试失败");
	}
	
	 
	
	web_reg_find("Search=Body",
	"SaveCount=sbxg",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("设备列表修改",
		"URL=http://{url}/water_bg/basestock/updatebasestock",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":1,\"no\":\"苹果\",\"name\":\"苹果99 Pro\",\"price\":\"10\",\"buyCount\":\"55\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{sbxg}"))==2){
	 lr_output_message("设备列表修改事务测试成功");
	}else{
     lr_output_message("设备列表修改事务测试失败");
	}
	
	 
	web_reg_find("Search=Body",
	"SaveCount=sbfplb",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("设备列表分配列表",
		"URL=http://{url}/water_bg/base/allBase",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{sbfplb}"))==1){
	 lr_output_message("设备列表分配列表测试成功");
	}else{
     lr_output_message("设备列表分配列表测试失败");
	}
	
	 
	web_reg_find("Search=Body",
	"SaveCount=sbfp",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("设备列表分配",
		"URL=http://{url}/water_bg/device/disStockToBase?baseId=8&stockId=5&disNum=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{sbfp}"))==2){
	 lr_output_message("设备列表分配测试成功");
	}else{
     lr_output_message("设备列表分配测试失败");
	}
	
	 
	web_reg_find("Search=Body",
	"SaveCount=sbdplb",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("设备列表待批列表",
		"URL=http://{url}/water_bg/ask/getAskAll0",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{sbdplb}"))==1){
	 lr_output_message("设备列表待批列表测试成功");
	}else{
     lr_output_message("设备列表待批列表测试失败");
	}
	
	 
	web_reg_find("Search=Body",
	"SaveCount=sbyplb",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("设备列表已批列表",
		"URL=http://{url}/water_bg/ask/getAskAll12",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{sbyplb}"))==1){
	 lr_end_transaction("设备列表事务",0);
	}else{
    lr_end_transaction("设备列表事务",1);
	}
	
	 
	
	lr_start_transaction("设备属性事务");
	
	web_reg_find("Search=Body",
	"SaveCount=sbsxtj",
	"Text=添加成功",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("设备属性添加",
		"URL=http://{url}/water_bg/device/addStatic",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":\"\",\"describe\":\"闫步榕的高玩\",\"unit\":\"个\",\"stockId\":\"1\"}",
		"LAST");
	
	if(atoi(lr_eval_string("{sbsxtj}"))==1){
	 lr_output_message("设备属性添加测试成功");
	}else{
     lr_output_message("设备属性添加测试失败");
	}
	
	 
	

	
	web_reg_find("Search=Body",
	"SaveCount=sbsxxg",
	"Text=修改成功",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("设备属性修改",
		"URL=http://{url}/water_bg/device/updateStatic",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":1,\"describe\":\"闫步榕\",\"unit\":\"根\",\"stockId\":1}",
		"LAST");
	
	if(atoi(lr_eval_string("{sbsxxg}"))==1){
	 lr_end_transaction("设备属性事务",0);
	}else{
    lr_end_transaction("设备属性事务",1);
	}
	
	 
	lr_start_transaction("爆管监控事务");
	
	web_reg_find("Search=Body",
	"SaveCount=bgjk",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("爆管监控",
		"URL=http://{url}/water_bg/boom/getAll",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	
	if(atoi(lr_eval_string("{bgjk}"))==1){
	 lr_end_transaction("爆管监控事务",0);
	}else{
    lr_end_transaction("爆管监控事务",1);
	}
	
	return 0;
}
# 5 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "Action2.c" 1
Action2()
{	
	web_reg_find("Search=Body",
	"SaveCount=dl",
	"Text=郭凡",
	"LAST");

	lr_start_transaction("登录事务");
	
	web_reg_save_param_json(
	"ParamName=token",
	"QueryString=$.data",
	"SEARCH_FILTERS",
	"Scope=BODY",
	"LAST");
	web_reg_save_param("ll",
	"LB=",
	"RB=",
	"Search=Body",
	"LAST");
	
	
	web_custom_request("登录",
	"URL=http://{url}/water_bg/user/login",
	"Method=POST",
	"TargetFrame=",
	"Resource=0",
	"RecContentType=application/json;charset=UTF-8",
	"Referer=",
	"EncType=application/json;charset=UTF-8",
	"Body={\"userName\":\"admin\",\"password\":\"123\"}",
	"LAST");
	
	lr_output_message("数量%s",lr_eval_string("{dl}"));
	
	lr_output_message("token%s",lr_eval_string("{token}"));
	if(atoi(lr_eval_string("{dl}"))==1){
	lr_end_transaction("登录事务",0);
	}else{
    lr_end_transaction("登录事务",1);
	}
	
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
	
	
	 
		lr_start_transaction("巡检地点-修改");
		
		web_reg_find("SaveCount=xiugai",
		"Text=修改成功",
		"LAST");
		
		web_add_header("Authorization",
		"{token}");
		
	web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/point/updatePoint",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":2,\"pointNo\":\"P0002\",\"pointName\":\"测试巡检点2\",\"address\":\"湖畔1\",\"remark\":\"741\"}",
		"LAST");

	lr_output_message("数量%s",lr_eval_string("{xiugai}"));	
	
	if(atoi(lr_eval_string("{xiugai}"))==1){
	lr_end_transaction("巡检地点-修改",0);
	}else{
    lr_end_transaction("巡检地点-修改",1);
	}
	
	
		 
	
		lr_start_transaction("巡检计划-添加");
		
		web_reg_find("SaveCount=xjjhtj",
		"Text=添加成功",
		"LAST");
		
		web_add_header("Authorization",
		"{token}");
		
		web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/patrolpoint/add",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"planNo\":\"吃吃吃\",\"planName\":\"吃草\",\"patType\":1,\"patCycle\":4,\"startDate\":\"2022-06-19T16:00:00.000Z\",\"endDate\":\"2022-06-28T16:00:00.000Z\",\"remark\":\"\",\"pointList\":[{\"id\":3,\"pointNo\":\"P0003\",\"pointName\":\"测试巡检点3\",\"address\":\"湖畔\",\"devNum\":13,\"remark\":\"真凉快\",\"devId\":null}],\"starDate\":\"\"}",
		"LAST");

	lr_output_message("数量%s",lr_eval_string("{xjjhtj}"));	
	
	if(atoi(lr_eval_string("{xjjhtj}"))==1){
	lr_end_transaction("巡检计划-添加",0);
	}else{
    lr_end_transaction("巡检计划-添加",1);
	}
	
	
	
	 
	lr_start_transaction("巡检计划-查看");
		
	web_reg_find("SaveCount=xjjhck",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/patrolpoint/findById?id=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{xjjhck}"));	
	
	if(atoi(lr_eval_string("{xjjhck}"))==1){
	lr_end_transaction("巡检计划-查看",0);
	}else{
    lr_end_transaction("巡检计划-查看",1);
	}
	

	 
	
		lr_start_transaction("巡检计划-查看-添加计划");
		
		web_reg_find("SaveCount=xjjhcktj",
		"Text=添加成功",
		"LAST");
		
		web_add_header("Authorization",
		"{token}");
		
		web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/patrolTask/addtask",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"executor\":\"wangkuang\",\"taskName\":\"信息\",\"startDate\":\"2022-06-06T16:00:00.000Z\",\"taskType\":\"plan\",\"endDate\":\"2022-06-12T16:00:00.000Z\",\"points\":[{\"id\":5,\"pointNo\":\"P0005\",\"pointName\":\"测试巡检点five\",\"address\":\"湖畔\",\"devNum\":13,\"remark\":\"真凉快\",\"devId\":null}],\"planId\":3}",
		"LAST");

	lr_output_message("数量%s",lr_eval_string("{xjjhcktj}"));	
	
	if(atoi(lr_eval_string("{xjjhcktj}"))==1){
	lr_end_transaction("巡检计划-查看-添加计划",0);
	}else{
    lr_end_transaction("巡检计划-查看-添加计划",1);
	}
	
	
	
	
	
	 
	
	lr_start_transaction("巡检计划-修改");
		
	web_reg_find("SaveCount=xjjhxg",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/patrolTask/findById?id=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{xjjhxg}"));	
	
	if(atoi(lr_eval_string("{xjjhxg}"))==1){
	lr_end_transaction("巡检计划-修改",0);
	}else{
    lr_end_transaction("巡检计划-修改",1);
	}
	
	
	
	 
	
	lr_start_transaction("巡检计划-修改-查看");
		
	web_reg_find("SaveCount=xjjhxgck",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/patrolTask/findByTaskId?id=60",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{xjjhxgck}"));	
	
	if(atoi(lr_eval_string("{xjjhxgck}"))==1){
	lr_end_transaction("巡检计划-修改-查看",0);
	}else{
    lr_end_transaction("巡检计划-修改-查看",1);
	}
	
	
	 
	
	lr_start_transaction("巡检审核-查看详情");
		
	web_reg_find("SaveCount=xjshckxq",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/situation/situationTaskId?id=16",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{xjshckxq}"));	
	
	if(atoi(lr_eval_string("{xjshckxq}"))==1){
	lr_end_transaction("巡检审核-查看详情",0);
	}else{
    lr_end_transaction("巡检审核-查看详情",1);
	}
	
	
	 
	
		lr_start_transaction("巡检审核-审核");
		
		web_reg_find("SaveCount=xjshsh",
		"Text=审核成功",
		"LAST");
		
		web_add_header("Authorization",
		"{token}");
		
		web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/check/checkTask",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"executor\":\"wangkuang\",\"taskName\":\"信息\",\"startDate\":\"2022-06-06T16:00:00.000Z\",\"taskType\":\"plan\",\"endDate\":\"2022-06-12T16:00:00.000Z\",\"points\":[{\"id\":5,\"pointNo\":\"P0005\",\"pointName\":\"测试巡检点five\",\"address\":\"湖畔\",\"devNum\":13,\"remark\":\"真凉快\",\"devId\":null}],\"planId\":3}",
		"LAST");

	lr_output_message("数量%s",lr_eval_string("{xjshsh}"));	
	
	if(atoi(lr_eval_string("{xjshsh}"))==1){
	lr_end_transaction("巡检审核-审核",0);
	}else{
    lr_end_transaction("巡检审核-审核",1);
	}
	
	
	
	 
	
	lr_start_transaction("系统管理-角色管理");
		
	web_reg_find("SaveCount=jsgl",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/role/list",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{jsgl}"));	
	
	if(atoi(lr_eval_string("{jsgl}"))==1){
	lr_end_transaction("系统管理-角色管理",0);
	}else{
    lr_end_transaction("系统管理-角色管理",1);
	}
	
	
	 
	
	lr_start_transaction("角色管理-分配管理");
		
	web_reg_find("SaveCount=fpgl",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/roleperm/tree?id=1",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{fpgl}"));	
	
	if(atoi(lr_eval_string("{fpgl}"))==1){
	lr_end_transaction("角色管理-分配管理",0);
	}else{
    lr_end_transaction("角色管理-分配管理",1);
	}
	
	
	 
	
	lr_start_transaction("系统管理-用户管理");
		
	web_reg_find("SaveCount=yhgl",
	"Text=OK",
	"LAST");
	
	web_add_header("Authorization",
	"{token}");
	
	
	web_url("web_url",
		"URL=http://{url}/water_bg/role/list",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");


	lr_output_message("数量%s",lr_eval_string("{yhgl}"));	
	
	if(atoi(lr_eval_string("{yhgl}"))==1){
	lr_end_transaction("系统管理-用户管理",0);
	}else{
    lr_end_transaction("系统管理-用户管理",1);
	}
	
	
	
	 
	
		lr_start_transaction("系统管理-用户管理-修改");
		
		web_reg_find("SaveCount=yhglxg",
		"Text=OK",
		"LAST");
		
		web_add_header("Authorization",
		"{token}");
		
		web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/user/updateUser",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"executor\":\"wangkuang\",\"taskName\":\"信息\",\"startDate\":\"2022-06-06T16:00:00.000Z\",\"taskType\":\"plan\",\"endDate\":\"2022-06-12T16:00:00.000Z\",\"points\":[{\"id\":5,\"pointNo\":\"P0005\",\"pointName\":\"测试巡检点five\",\"address\":\"湖畔\",\"devNum\":13,\"remark\":\"真凉快\",\"devId\":null}],\"planId\":3}",
		"LAST");

	lr_output_message("数量%s",lr_eval_string("{yhglxg}"));	
	
	if(atoi(lr_eval_string("{yhglxg}"))==1){
	lr_end_transaction("系统管理-用户管理-修改",0);
	}else{
    lr_end_transaction("系统管理-用户管理-修改",1);
	}
	
	return 0;
}
# 6 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "Action3.c" 1
Action3()
{	
	web_reg_find("SaveCount=dlxy",
		"Text=范驰",
		"LAST");

	web_reg_save_param_json(
		"ParamName=token",
		"QueryString=$.data",
		"SEARCH_FILTERS",
		"Scope=BODY",
		"LAST");

	
		web_custom_request("登陆测试",
		"URL=http://{url}/water_bg/user/login",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"userName\":\"admin\",\"password\":\"123\"}",
		"LAST");

	

	
		
	lr_output_message("数量为%s。", lr_eval_string("{dlxy}"));	
		
	if (atoi(lr_eval_string("{dlxy}")) == 1) {
          lr_output_message("访问首页测试成功！");
      } else {
          lr_output_message("访问首页测试失败!");
      }
	
	
	
	web_reg_find("SaveCount=jrwxxtxy",
		"Text=OK",
		"LAST");
	
	
	web_add_header("Authorization",
		"{token}");
	
	
	web_custom_request("进入维修系统首页测试",
		"URL=http://{url}/water_bg/repiar/circular",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"dealWithDate\":\"\",\"endDate\":\"\"}",
		"LAST");
	
	if (atoi(lr_eval_string("{jrwxxtxy}")) == 1) {
          lr_output_message("进入维修系统成功！");
      } else {
          lr_output_message("进入维修系统失败!");
      }


 
	
	web_reg_find("SaveCount=jrwpgdxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("进入未派工单",
		"URL=http://{url}/water_bg/user/repair",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
	
	if (atoi(lr_eval_string("{jrwpgdxy}")) == 1) {
          lr_output_message("进入未派工单成功！");
      } else {
          lr_output_message("进入未派工单失败!");
      }
	
 
	
	web_reg_find("SaveCount=wpgdcxxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");

	web_custom_request("未派工单查询",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json;charset=UTF-8",
		"Body={\"state\":1,\"source\":\"撤硕听说\",\"eventId\":\"\",\"reflectPeople\":\"郭凡\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":4,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");
	
	if (atoi(lr_eval_string("{wpgdcxxy}")) == 1) {
          lr_output_message("未派工单查询成功！");
      } else {
          lr_output_message("未派工单查询失败!");
      }
	
 
	web_reg_find("SaveCount=wpgdtjxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
		
	web_custom_request("添加未派工单",
		"URL=http://{url}/water_bg/repair/add",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json;charset=UTF-8",
		"Body={\"reflectPeople\":\"郭凡\",\"source\":\"刘星跟他说的\",\"phone\":\"13353430762\",\"email\":\"1727254353@qq.com\",\"reflectUnit\":\"郭凡破防时刻\",\"reflectArea\":\"秦岭山下郭凡家\",\"reflectContent\":\"破防了\",\"reflectClass\":\"低\",\"happenDate\":\"2022-06-30 20:12:38\",\"happenArea\":\"6教\",\"eventId\":2,\"endDate\":\"2022-06-30 20:13:06\"}",
		"LAST");

	if (atoi(lr_eval_string("{wpgdtjxy}")) == 1) {
          lr_output_message("未派工单添加成功！");
      } else {
          lr_output_message("未派工单添加失败!");
      }
	
 
	web_reg_find("SaveCount=wpgdczxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("未派工单重置",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json;charset=UTF-8",
		"Body={\"state\":1,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":1,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");

	if (atoi(lr_eval_string("{wpgdczxy}")) == 1) {
          lr_output_message("未派工单重置成功！");
      } else {
          lr_output_message("未派工单重置失败!");
      }
      
 
	
	web_reg_find("SaveCount=wpgdxgxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
		
	web_custom_request("未派工单修改",
		"URL=http://{url}/water_bg/repair/update",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json;charset=UTF-8",
		"Body={\"id\":59,\"reflectPeople\":\"郭凡\",\"source\":\"刘星跟他说的\",\"phone\":\"13353430762\",\"email\":\"1727254353@qq.com\",\"reflectUnit\":\"郭凡破防时刻\",\"reflectArea\":\"秦岭山下郭凡家\",\"reflectClass\":\"低\",\"happenDate\":\"2022-06-30 20:12:38\",\"happenArea\":\"6教\",\"eventId\":2,\"endDate\":\"2022-06-30 20:13:06\",\"state\":1,\"stateName\":\"未指派\",\"userId\":17}",
		"LAST");

	if (atoi(lr_eval_string("{wpgdxgxy}")) == 1) {
          lr_output_message("未派工单修改成功！");
      } else {
          lr_output_message("未派工单修改失败!");
      }
      
 
	web_reg_find("SaveCount=wpgdscxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
		
	web_custom_request("未派工单删除",
		"URL=http://{url}/water_bg/repair/delete?id=55",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
		
	if (atoi(lr_eval_string("{wpgdscxy}")) == 1) {
          lr_output_message("未派工单删除成功！");
      } else {
          lr_output_message("未派工单删除失败!");
      }

	
 

	web_reg_find("SaveCount=jrypgdxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("进入已派工单",
		"URL=http://{url}/water_bg/user/repair",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
	
	if (atoi(lr_eval_string("{jrypgdxy}")) == 1) {
          lr_output_message("进入已派工单成功！");
      } else {
          lr_output_message("进入已派工单失败!");
      }
      


	
	
 
	
	web_reg_find("SaveCount=ypgdczxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("已派工单重置",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"state\":2,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":0,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");

	if (atoi(lr_eval_string("{ypgdczxy}")) == 1) {
          lr_output_message("已派工单重置成功！");
      } else {
          lr_output_message("已派工单重置失败!");
      }
      
      
 
	web_reg_find("SaveCount=ypgdqshxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("已派工单去审核",
		"URL=http://{url}/water_bg/repair/updateState?id=49&state=3",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
	
	if (atoi(lr_eval_string("{ypgdqshxy}")) == 1) {
          lr_output_message("已派工单去审核成功！");
      } else {
          lr_output_message("已派工单去审核失败!");
      }
	
 
	web_reg_find("SaveCount=ypgdscxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("已派工单删除",
		"URL=http://{url}/water_bg/repair/delete?id=50",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
		
	if (atoi(lr_eval_string("{ypgdscxy}")) == 1) {
          lr_output_message("已派工单删除成功！");
      } else {
          lr_output_message("已派工单删除失败!");
      }

	
	
	
 
	
	web_reg_find("SaveCount=jrwshgdxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
		
	web_custom_request("进入未审核工单",
		"URL=http://{url}/water_bg/user/repair",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
		
	if (atoi(lr_eval_string("{jrwshgdxy}")) == 1) {
          lr_output_message("进入未审核工单成功！");
      } else {
          lr_output_message("进入未审核工单失败!");
      }
	
	
 
	web_reg_find("SaveCount=wshgdcxxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("未审核工单查询",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"state\":3,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":1,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");

	if (atoi(lr_eval_string("{wshgdcxxy}")) == 1) {
          lr_output_message("未审核工单查询成功！");
      } else {
          lr_output_message("未审核工单查询失败!");
      }
      
      
 
	
	web_reg_find("SaveCount=wshgdczxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
		
	web_custom_request("未审核工单重置",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"state\":3,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":1,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");

	if (atoi(lr_eval_string("{wshgdczxy}")) == 1) {
          lr_output_message("未审核工单查询成功！");
      } else {
          lr_output_message("未审核工单查询失败!");
      }
		
	
	
 

	web_reg_find("SaveCount=wshgdshxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("未审核工单审核",
		"URL=http://{url}/water_bg/repair/updateState?id=39&state=4",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");

	if (atoi(lr_eval_string("{wshgdshxy}")) == 1) {
          lr_output_message("未审核工单审核成功！");
      } else {
          lr_output_message("未审核工单审核失败!");
      }
      
      
 
	web_reg_find("SaveCount=wshgdscxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("未审核工单删除",
		"URL=http://{url}/water_bg/repair/delete?id=49",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");

	if (atoi(lr_eval_string("{wshgdscxy}")) == 1) {
          lr_output_message("未审核工单删除成功！");
      } else {
          lr_output_message("未审核工单删除失败!");
      }
	
 
	web_reg_find("SaveCount=jryshgdxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("进入已审核工单",
		"URL=http://{url}/water_bg/repair/delete?id=49",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");

	if (atoi(lr_eval_string("{jryshgdxy}")) == 1) {
          lr_output_message("未审核工单删除成功！");
      } else {
          lr_output_message("未审核工单删除失败!");
      }
      
 
	
	web_reg_find("SaveCount=yshgdcxxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");

	web_custom_request("已审核工单查询",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"state\":4,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":1,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");
		
	if (atoi(lr_eval_string("{yshgdcxxy}")) == 1) {
          lr_output_message("已审核工单查询成功！");
      } else {
          lr_output_message("已审核工单查询失败!");
      }

 
	web_reg_find("SaveCount=yshgdczxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("已审核工单重置",
		"URL=http://{url}/water_bg/worker/list",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"state\":4,\"source\":\"\",\"eventId\":\"\",\"reflectPeople\":\"\",\"phone\":\"\",\"reflectUnit\":\"\",\"reflectArea\":\"\",\"pappenArea\":\"\",\"pageIndex\":1,\"happenDate\":\"\",\"endDate\":\"\"}",
		"LAST");

	if (atoi(lr_eval_string("{yshgdczxy}")) == 1) {
          lr_output_message("已审核工单重置成功！");
      } else {
          lr_output_message("已审核工单重置失败!");
      }
      
      
 
	web_reg_find("SaveCount=yshgdscxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("web_custom_request",
		"URL=http://{url}/water_bg/repair/delete?id=10",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
	if (atoi(lr_eval_string("{yshgdscxy}")) == 1) {
          lr_output_message("已审核工单删除成功！");
      } else {
          lr_output_message("已审核工单删除失败!");
      }
	
	
 
	web_reg_find("SaveCount=jrsbwxxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
   
	web_custom_request("进入设备维修",
		"URL=http://{url}/water_bg/baseRepair/List",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"createDate\":\"\",\"endDate\":\"\",\"pageIndex\":\"1\",\"pageSize\":\"5\",\"childStatus\":\"\",\"baseName\":\"\"}",
		"LAST");
	if (atoi(lr_eval_string("{jrsbwxxy}")) == 1) {
          lr_output_message("进入设备维修成功！");
      } else {
          lr_output_message("进入设备维修失败!");
      }

 
	
	web_reg_find("SaveCount=sbwxcxxy",
		"Text=ok",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
   
   	web_custom_request("设备维修查询",
		"URL=http://{url}/water_bg/baseRepair/List",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"createDate\":\"\",\"endDate\":\"\",\"pageIndex\":\"1\",\"pageSize\":\"5\",\"childStatus\":\"已报修\",\"baseName\":\"\"}",
		"LAST");
	if (atoi(lr_eval_string("{sbwxcxxy}")) == 1) {
          lr_output_message("设备维修查询成功！");
      } else {
          lr_output_message("设备维修查询失败!");
      }
	
   
   
 
	web_reg_find("SaveCount=sbwxwcjxxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
   
   

	web_custom_request("设备维修完成检修",
		"URL=http://{url}/water_bg/baseRepair/updateStatus?deviceId=27",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
	if (atoi(lr_eval_string("{sbwxwcjxxy}")) == 1) {
          lr_output_message("设备维修完成检修成功！");
      } else {
          lr_output_message("设备维修完成检修失败!");
      }
	
	
 

	web_reg_find("SaveCount=sbwxscxy",
		"Text=OK",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
   
   
   

	web_custom_request("设备维修删除",
		"URL=http://{url}/water_bg/baseRepair/delete?id=28",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body=",
		"LAST");
		
	if (atoi(lr_eval_string("{sbwxscxy}")) == 1) {
          lr_output_message("设备维修删除成功！");
      } else {
          lr_output_message("设备维修完删除失败!");
      }
	
	return 0;
}
# 7 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "Action4.c" 1
Action4()
{	
	web_reg_find("SaveCount=login_check_point",
		"Text=\"msg\":\"范驰\"",
		"LAST");
	
	lr_start_transaction("登录事务");

	web_reg_save_param_json(
		"ParamName=token",
		"QueryString=$.data",
		"SEARCH_FILTERS",
		"Scope=BODY",
		"LAST");
	
	web_custom_request("登录",
		"URL=http://{url}/water_bg/user/login",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"userName\":\"admin\",\"password\":\"123\"}",
		"LAST");

	lr_output_message(lr_eval_string("{login_check_point}"));
	
	if (atoi(lr_eval_string("{login_check_point}")) == 1){
		lr_end_transaction("登录事务", 0);
	} else {
		lr_end_transaction("登录事务", 1);

	}
	
	
	web_reg_find("SaveCount=getBaseStocks_check_point",
		"Text=\"msg\":\"OK\"",
		"LAST");
	
	lr_start_transaction("采购审核事务");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("添加采购项页面",
		"URL=http://{url}/water_bg/buy/getBaseStocks",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	lr_output_message(lr_eval_string("{getBaseStocks_check_point}"));

	
	if (atoi(lr_eval_string("{getBaseStocks_check_point}")) == 1){
		lr_output_message("访问添加采购项页面测试成功！");
	} else {
		lr_output_message("访问添加采购项页面测试失败！");
	}
	
	
	
	web_reg_find("SaveCount=addCheck_check_point",
		"Text=\"msg\":\"OK\"",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("添加采购项",
		"URL=http://{url}/water_bg/buy/addCheck",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"buyman\":\"郭凡字仲达\",\"stockId\":6,\"useDate\":\"2022-06-21\",\"buySum\":\"1\",\"buyDate\":\"2022-06-27\",\"description\":\"郭凡字仲达\",\"money\":100,\"price\":100}",
		"LAST");

	lr_output_message(lr_eval_string("{addCheck_check_point}"));

	if (atoi(lr_eval_string("{addCheck_check_point}")) == 2){
		lr_output_message("添加采购项测试成功！");
	} else {
		lr_output_message("添加采购项测试失败！");
	}
	
	
	web_reg_find("SaveCount=buycheck_check_point",
		"Text=\"msg\":\"OK\"",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("采购审核通过操作",
		"URL=http://{url}/water_bg/buy/check",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":12,\"stockId\":6,\"description\":\"郭凡字仲达\",\"useDate\":\"2022-06-20\",\"buySum\":1,\"money\":100,\"buyDate\":\"2022-06-26\",\"checkDate\":null,\"isChecked\":\"未审核\",\"checkman\":null,\"baseStock\":null,\"no\":\"cl21312\",\"name\":\"加氯机\",\"buyman\":\"郭凡字仲达\",\"status\":null,\"pageIndex\":null}",
		"LAST");

	lr_output_message(lr_eval_string("{buycheck_check_point}"));

	
	if (atoi(lr_eval_string("{buycheck_check_point}")) == 2){
		lr_output_message("采购审核通过操作测试成功！");
	} else {
		lr_output_message("采购审核通过操作测试失败！");
	}
	
	
	web_reg_find("SaveCount=buycheck_update_point",
		"Text=\"msg\":\"OK\"",
		"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("采购反馈提交操作",
		"URL=http://{url}/water_bg/buyback/update",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":40,\"buycheckId\":12,\"realprice\":\"100\",\"realbuyCount\":\"1\",\"realcost\":\"100\",\"dec\":\"郭凡字仲达\",\"status\":\"已完成\"}",
		"LAST");

	lr_output_message(lr_eval_string("{buycheck_update_point}"));

	
	if (atoi(lr_eval_string("{buycheck_update_point}")) == 2){
		lr_end_transaction("采购审核事务", 0);
	} else {
		lr_end_transaction("采购审核事务", 1);
	}
	
	
	web_reg_find("SaveCount=gmsgetallpump_check_point",
		"Text=\"msg\":\"OK\"",
		"LAST");
	
	lr_start_transaction("G-M-S泵站事务");
	
	web_add_header("Authorization",
		"{token}");
	
	web_url("泵站信息页面",
		"URL=http://{url}/water_bg/gms/getallpump",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"LAST");
	lr_output_message(lr_eval_string("{gmsgetallpump_check_point}"));

	
	if (atoi(lr_eval_string("{gmsgetallpump_check_point}")) == 1){
		lr_output_message("访问泵站信息页面测试成功！");
	} else {
		lr_output_message("访问泵站信息页面测试失败！");
	}
	
	
	web_reg_find("SaveCount=gmsaddpump_check_point",
	"Text=\"msg\":\"OK\"",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("添加站点数据",
		"URL=http://{url}/water_bg/gms/addpump",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"pumpname\":\"ABC\",\"pumptype\":\"1\",\"gas\":\"185.63\",\"intpower\":\"185.63\",\"tp\":\"185.63\",\"outpower\":\"185.63\",\"temperature\":\"185.63\",\"userId\":7,\"pumpsize\":\"大\"}",
		"LAST");

	lr_output_message(lr_eval_string("{gmsaddpump_check_point}"));

	
	if (atoi(lr_eval_string("{gmsaddpump_check_point}")) == 2){
		lr_output_message("添加站点数据测试成功！");
	} else {
		lr_output_message("添加站点数据测试失败！");
	}
	
	
	web_reg_find("SaveCount=gmsupdatepump_check_point",
	"Text=\"msg\":\"OK\"",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("修改站点数据",
		"URL=http://{url}/water_bg/gms/updatepump",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"id\":15,\"pumpname\":\"ABC\",\"pumptype\":\"1\",\"gas\":185.63,\"tp\":185.63,\"intpower\":185.63,\"outpower\":185.63,\"temperature\":185.63,\"userId\":7,\"name\":\"卢文龙\",\"pumpsize\":\"大\"}",
		"LAST");

	lr_output_message(lr_eval_string("{gmsupdatepump_check_point}"));

	
	if (atoi(lr_eval_string("{gmsupdatepump_check_point}")) == 2){
		lr_output_message("修改站点数据测试成功！");
	} else {
		lr_output_message("修改站点数据测试失败！");
	}
	
	
	web_reg_find("SaveCount=gmsgetpumpdata_check_point",
	"Text=\"msg\":\"OK\"",
	"LAST");
	
	web_add_header("Authorization",
		"{token}");
	
	web_custom_request("泵站数据信息查询",
		"URL=http://{url}/water_bg/gms/getpumpdata",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={\"pumpId\":1,\"time\":\"2021-03-16\",\"pageIndex\":1}",
		"LAST");

	lr_output_message(lr_eval_string("{gmsgetpumpdata_check_point}"));

	
	if (atoi(lr_eval_string("{gmsgetpumpdata_check_point}")) == 1){
		lr_end_transaction("G-M-S泵站事务", 0);
	} else {
		lr_end_transaction("G-M-S泵站事务", 1);
	}
	
	return 0;
}
# 8 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 9 "d:\\documents\\lr_script\\webhttphtml7\\\\combined_WebHttpHtml7.c" 2

